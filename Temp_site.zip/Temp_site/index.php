<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "temperature_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get average temperature, current humidity, highest and lowest temperature
$query = "SELECT ROUND(AVG(temperature), 2) as avg_temp, MAX(temperature) as max_temp, MIN(temperature) as min_temp, humidity FROM temp ORDER BY timestamp DESC LIMIT 1";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $avg_temp = $row["avg_temp"];
    $max_temp = $row["max_temp"];
    $min_temp = $row["min_temp"];
    $humidity = $row["humidity"];
} else {
    $avg_temp = "--";
    $max_temp = "--";
    $min_temp = "--";
    $humidity = "--";
}

$suggestion = getSuggestion($avg_temp);

function getSuggestion($temp) {
    if ($temp < 10) {
        return "Wear a coat and warm clothes.";
    } elseif ($temp < 20) {
        return "A light jacket should be fine.";
    } else {
        return "It's warm, wear light clothes.";
    }
}

// Get the current page number and set the limit for records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get hourly averages with pagination
$readings_query = "
    SELECT
        DATE_FORMAT(timestamp, '%Y-%m-%d %h:00 %p') as formatted_timestamp,
        AVG(temperature) as avg_temp,
        AVG(humidity) as avg_humidity
    FROM temp
    GROUP BY YEAR(timestamp), MONTH(timestamp), DAY(timestamp), HOUR(timestamp)
    ORDER BY timestamp DESC
    LIMIT $limit OFFSET $offset";
$readings_result = $conn->query($readings_query);

// Get the total number of hourly records
$total_query = "
    SELECT COUNT(*) as total
    FROM (
        SELECT
            DATE_FORMAT(timestamp, '%Y-%m-%d %h:00 %p') as formatted_timestamp
        FROM temp
        GROUP BY YEAR(timestamp), MONTH(timestamp), DAY(timestamp), HOUR(timestamp)
    ) as hourly_data";
$total_result = $conn->query($total_query);
$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $limit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temperature and Humidity Monitor</title>
    <link rel="stylesheet" href="src/styles.css">
</head>
<body>
    <header>
        <h1>Temperature and Humidity Monitor</h1>
    </header>
    <main>
        <div class="data-section">
            <h2>Current Data</h2>
            <div class="data-item">
                <div class="data-label">Average Temperature (Last 6 hours):</div>
                <div class="data-value"><?php echo $avg_temp; ?>°C</div>
            </div>
            <div class="data-item">
                <div class="data-label">Current Humidity:</div>
                <div class="data-value"><?php echo $humidity; ?>%</div>
            </div>
            <div class="data-item">
                <div class="data-label">Highest Temperature:</div>
                <div class="data-value"><?php echo $max_temp; ?>°C</div>
            </div>
            <div class="data-item">
                <div class="data-label">Lowest Temperature:</div>
                <div class="data-value"><?php echo $min_temp; ?>°C</div>
            </div>
            <div class="data-item">
                <div class="data-label">Suggested Clothing:</div>
                <div class="data-value"><?php echo $suggestion; ?></div>
            </div>
        </div>
        <div class="readings-section">
            <h2>All Readings - Page <?php echo $page; ?></h2> <!-- Added Page Indicator -->
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Average Temperature (°C)</th>
                        <th>Average Humidity (%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($readings_result->num_rows > 0) {
                        while ($row = $readings_result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['formatted_timestamp']}</td>
                                <td>" . round($row['avg_temp'], 2) . "</td>
                                <td>" . round($row['avg_humidity'], 2) . "</td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No readings available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <div class="pagination">
                <?php
                for ($i = 1; $i <= $total_pages; $i++) {
                    echo "<a href='?page=$i' class='" . ($i == $page ? "active" : "") . "'>$i</a>";
                }
                ?>
            </div>
        </div>
    </main>
</body>
</html>
