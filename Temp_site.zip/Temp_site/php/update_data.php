<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "temperature_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['temperature']) && isset($input['humidity'])) {
    $temp = $input['temperature'];
    $humidity = $input['humidity'];

    $stmt = $conn->prepare("INSERT INTO temp (temperature, humidity) VALUES (?, ?)");
    $stmt->bind_param("dd", $temp, $humidity);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to insert data']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
}

$conn->close();
?>
