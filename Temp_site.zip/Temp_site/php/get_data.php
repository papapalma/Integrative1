<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "temperature_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT AVG(temperature) as avg_temp, humidity FROM temp ORDER BY timestamp DESC LIMIT 1";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $avg_temp = $row["avg_temp"];
    $humidity = $row["humidity"];
} else {
    $avg_temp = "--";
    $humidity = "--";
}

$suggestion = getSuggestion($avg_temp);

function getSuggestion($temp) {
    if ($temp < 10) {
        return "Wear a coat and warm clothes.";
    } elseif ($temp < 20) {
        return "A light jacket should be fine.";
    } else {
        return "It's warm, wear light clothes.";
    }
}

echo json_encode([
    "avg_temp" => $avg_temp,
    "humidity" => $humidity,
    "suggestion" => $suggestion
]);

$conn->close();
?>
